<div id="footer">
    <hr width="80%" class=" m-auto mt-5">
</div>