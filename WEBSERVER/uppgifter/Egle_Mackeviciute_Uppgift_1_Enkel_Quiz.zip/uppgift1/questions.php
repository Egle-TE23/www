<?php 

$questions=[
    ["Vem är best?","jag","du","vi","ni",1],
    ["Hur många ben har ett stabilt bord?","-1","2","3","4",4],
    ["Hur många år går det varje dag","0.0052","0.0027","0","minst 1?",2],
    ["Kan du andas?","ja","nej","hur mycket?","kanske",1],
    ["Vilken färg är bäst för apetiten","blå","lila","röd","vit",3],
    ["Hur många tänder har en storkäftad vuxen person?","18","32","28","36",2],
    ["Vilken del av kon är Nötbringa","bröst","ben","kind","rygg",1],
    ["Vad använder man för att äta kött?","händer","sax","gaffel","sked",3],
    ["Hur stor bitkraft har en människa?","30kg","5kg","200kg","70kg",4],
    ["Hur många liter blood har en människa?","5","7","2","3",1],
    ["Vem är best?","jag","inte du","inte vi","inte ni",1],
    ["Vad är Egles favorit spirit i clash","ice spirit","fire spirit","electro spirit","heal spirit",4],
];

