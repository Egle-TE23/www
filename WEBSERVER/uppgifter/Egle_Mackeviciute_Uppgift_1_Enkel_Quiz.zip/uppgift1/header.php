<div id="header">
    <h1><a href="welcome.php">THE SUPER COOL QUIZZZZZ tm</a></h1>
</div>